﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using SpatialLite.Osm;
using SpatialLite.Core.API;
using SpatialLite.Osm.Geometries;
using SpatialLite.Osm.IO;
using SpatialLite.Osm.IO.Xml;
using System.Diagnostics;

namespace OsmFiltering {
	class Program {
		static void Main(string[] args) {
			string inputFile = "input.pbf";
			string outputFile = "output.pbf";

			for (int i = 0; i < 3; i++) {
				Stopwatch watch = new Stopwatch();
				watch.Start();

				ClipInclude(inputFile, outputFile);
				//ClipExclude(inputFile, outputFile);

				watch.Stop();
				Console.WriteLine("Runtime: " + watch.Elapsed);

			}

			Console.ReadLine();
		}

		static void ClipInclude(string inputFile, string outputFile) {
			SpatialLite.Core.API.Envelope bbox = new SpatialLite.Core.API.Envelope(new Coordinate[] { new Coordinate(16.06329, 50.50976), new Coordinate(16.07583, 50.50234) });
			IEntityInfo info = null;

			IdTracker tracker = new IdTracker();
			IdTracker outsideTracker = new IdTracker();

			OsmReaderSettings readerSettings = new OsmReaderSettings() { ReadMetadata = true };
			PbfWriterSettings writerSettings = new PbfWriterSettings() { ProgramName = "OsmFilter_Demo", Compression = CompressionMode.ZlibDeflate, UseDenseFormat = true, WriteMetadata = true };
			
			using (PbfReader reader = new PbfReader(inputFile, readerSettings)) {
					while ((info = reader.Read()) != null) {
						if (info.EntityType == EntityType.Node) {
							Coordinate position = new Coordinate(((NodeInfo)info).Longitude, ((NodeInfo)info).Latitude);
							if (bbox.MinX <= position.X && bbox.MaxX >= position.X && bbox.MinY <= position.Y && bbox.MaxY >= position.Y) {
								tracker.Add(info.ID);
							}
						}
						else if (info.EntityType == EntityType.Way) {
							WayInfo way = (WayInfo)info;
							if (way.Nodes.Any(nodeId => tracker.Contains(nodeId))) {
								tracker.Insert(info.ID);
								var outsideNodes = way.Nodes.Where(nodeId => tracker.Contains(nodeId) == false);
								foreach (var nodeId in outsideNodes) {
									outsideTracker.Insert(nodeId);
								}
							}
						}
						else if (info.EntityType == EntityType.Relation) {
							RelationInfo relation = (RelationInfo)info;
							if (relation.Members.Any(member => tracker.Contains(member.Reference))) {
								tracker.Insert(info.ID);
							}
						}
					}
			}

			using (PbfReader reader = new PbfReader(inputFile, readerSettings)) {
				using (PbfWriter writer = new PbfWriter(outputFile, writerSettings)) {

					while ((info = reader.Read()) != null) {
						if (tracker.Contains(info.ID) || outsideTracker.Contains(info.ID)) {
							writer.Write(info);
						}
					}
				}
			}
		}

		static void ClipExclude(string inputFile, string outputFile) {
			SpatialLite.Core.API.Envelope bbox = new SpatialLite.Core.API.Envelope(new Coordinate[] { new Coordinate(16.06329, 50.50976), new Coordinate(16.07583, 50.50234) });
			IEntityInfo info = null;

			IdTracker tracker = new IdTracker();

			OsmReaderSettings readerSettings = new OsmReaderSettings() { ReadMetadata = true };
			PbfWriterSettings writerSettings = new PbfWriterSettings() { ProgramName = "OsmFilter_Demo", Compression = CompressionMode.ZlibDeflate, UseDenseFormat = true, WriteMetadata = true };
						
			int count = 0;
			using (PbfReader reader = new PbfReader(inputFile, readerSettings)) {
				using (PbfWriter writer = new PbfWriter(outputFile, writerSettings)) {

					while ((info = reader.Read()) != null) {
						if (info.EntityType == EntityType.Node) {
							Coordinate position = new Coordinate(((NodeInfo)info).Longitude, ((NodeInfo)info).Latitude);
							if (bbox.MinX <= position.X && bbox.MaxX >= position.X && bbox.MinY <= position.Y && bbox.MaxY >= position.Y) {
								writer.Write(info);
								tracker.Add(info.ID);
							}
						}
						else if (info.EntityType == EntityType.Way) {
							WayInfo way = (WayInfo)info;
							if (way.Nodes.All(nodeId => tracker.Contains(nodeId))) {
								writer.Write(info);
								tracker.Insert(info.ID);
							}
						}
						else if (info.EntityType == EntityType.Relation) {
							RelationInfo relation = (RelationInfo)info;
							if (relation.Members.All(member => tracker.Contains(member.Reference))) {
								writer.Write(info);
							}
						}
					}
				}
			}

			Console.WriteLine(count);
		}
	}
}
