﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OsmFiltering {
	public class IdTracker {
		private List<IdRange> _storage = new List<IdRange>();
		private IdRange _range = IdRange.Empty;

		/// <summary>
		/// Adds ID to the tracker. Add method expects IDs in ascending order.
		/// </summary>
		/// <param name="id">ID to add</param>
		public void Add(int id) {
			if (_range.Equals(IdRange.Empty)) {
				_range.From = id;
				_range.To = id;
			}
			else {
				if (_range.To == id - 1) {
					_range.To++;
				}
				else {
					_storage.Add(_range);
					_range = new IdRange() { From = id, To = id };
				}
			}
		}

		/// <summary>
		/// Adds ID to the tracker. Insert method doesn't need IDs in ascending order.
		/// </summary>
		/// <param name="id">ID to add</param>
		public void Insert(int id) {
			if (this.Contains(id) == false) {
				if (_storage.Count > 0) {
					this.BinaryInsert(0, _storage.Count - 1, id);
				}
				else {
					this.Add(id);
					this.Flush();
				}
			}
		}
		
		/// <summary>
		/// Checks wheter tracker contains specific ID
		/// </summary>
		/// <param name="id">ID to locate in the tracker.</param>
		/// <returns>true if ID is in the tracker, oterwise false</returns>
		public bool Contains(int id) {
			if (_storage.Count > 0) {
				return this.BinarySearch(0, _storage.Count - 1, id);
			}

			return false;
		}
		
		private bool BinarySearch(int lIndex, int uIndex, int id) {
			if (lIndex == uIndex) {
				return _storage[lIndex].Compare(id) == 0;
			}

			if (lIndex == uIndex - 1) {
				return (_storage[lIndex].Compare(id) == 0) || (_storage[uIndex].Compare(id) == 0);
			}

			int index = lIndex + (int)Math.Floor((uIndex - lIndex) / 2.0);
			switch(_storage[index].Compare(id)) {
				case -1: return this.BinarySearch(lIndex, index, id);
				case 0: return true;
				case 1: return this.BinarySearch(index, uIndex, id);
			}

			throw new InvalidOperationException();
		}

		private void BinaryInsert(int lIndex, int uIndex, int id) {
			if (lIndex == uIndex || lIndex == uIndex - 1) {
				if (_storage[lIndex].Compare(id) == -1) {
					_storage.Insert(lIndex, new IdRange() { From = id, To = id });
				}
				else if (_storage[uIndex].Compare(id) == -1) {
					_storage.Insert(uIndex, new IdRange() { From = id, To = id });
				}
				else {
					_storage.Insert(uIndex +1, new IdRange() { From = id, To = id });
				}

				return;
			}
			
			int index = lIndex + (int)Math.Floor((uIndex - lIndex) / 2.0);
			int dir = _storage[index].Compare(id);
			if(dir == -1) {
				this.BinaryInsert(lIndex, index, id);
			}
			else if(dir == 1) {
				this.BinaryInsert(index, uIndex, id);
			}
		}

		public void Flush() {
			if (!_range.Equals(IdRange.Empty)) {
				_storage.Add(_range);		
			}
		}
	}

	struct IdRange {
		public int From;
		public int To;

		public int Compare(int id) {
			if (id < this.From) {
				return -1;
			}
			else if (id > this.To) {
				return 1;
			}
			else {
				return 0;
			}
		}
		
		public static IdRange Empty = new IdRange() { From = int.MinValue, To = int.MinValue };
	}
}
